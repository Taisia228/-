function Click() {
    document.getElementById("text").textContent = "Вы кликнули дважды!"
}