function Body() {
    let random = '#' + Math.floor(Math.random() * 1000);
    document.body.style.backgroundColor = random;
}