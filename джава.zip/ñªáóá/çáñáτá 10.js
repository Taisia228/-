let count = 0
alert("Добро пожаловаться в Викторину! В Викторине всего 3 вопроса, за каждый правильный ответ начисляется 1 балл.")
var input_vectorina1 = prompt("1. Сколько у человека ног?")

if (input_vectorina1 == 2) {
    alert("Правильно!")
    count++;
}

else {
    alert("Не правильно!")
}

var input_vectorina2 = prompt("2. Сколько океанов на земле?")
if (input_vectorina2 == 5) {
    alert("Правильно!")
    count++;
}

else {
    alert("Не правильно!")
}

var input_vectorina3 = prompt("3. Сколько планет в Солнечной системе?")
if (input_vectorina3 == 8) {
    alert("Правильно!")
    count++;
}

else {
    alert("Не правильно!")
}

alert("Вы набрали " + count + " очков!");