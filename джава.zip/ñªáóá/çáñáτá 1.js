var age = prompt("Сколько Вам лет?");

if (age >= 18) {
    console.log("Вы совершеннолетний");
}

else {
    console.log("Вы несовершеннолетний");
}