var input = prompt("Солнце - это звезда?");

if (input === "да" || input === "Да") {
    console.log("Правильно");
}

else if (input === "нет" || input === "Нет") {
    console.log("Неправильно, солнце — это звезда.");
}

else {
    console.log("Введи корректно свой ответ")
}