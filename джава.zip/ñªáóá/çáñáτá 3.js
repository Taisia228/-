<button onclick="document.body.style.backgroundColor = 'blue'">Сменить фон</button>
