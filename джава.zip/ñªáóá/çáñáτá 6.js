for (let a = 1; a < 21; a++) {
    if (a % 2 == 0) {
        console.log("Четное: " + a);
    }

    else {
        console.log("Не четное: " + a);
    }
}